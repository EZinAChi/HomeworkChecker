from django.shortcuts import render
from prac.models import Quest,StudeA
 
 
import pyodbc
from django.http import HttpResponse,HttpResponseRedirect 
from django.template import loader
 
from django.urls import reverse
from django.core.exceptions import ValidationError
from django import forms
from django.contrib import messages
 #connect the Answer table let ,display the question to the students
def connectstudent(request):
    
       condata=pyodbc.connect('Driver={sql server};'
       'Server=LAPTOP-M7N01MTM;'
       'Database=test;' 
       'Trusted_Connection=yes;')
       cursor=condata.cursor()
       #last slution change from null to not
       #we=cursor.execute("SELECT Question.questionID, Question.question, Answer.StudentAnswer FROM Question INNER JOIN Answer ON Question.questionID=Answer.questionID;")
      
       #cursor.execute("INSERT INTO Answer (questionID) SELECT questionID FROM Question where questionID=1;")
       #cursor.execute("INSERT Answer (questionID) SELECT questionID FROM  Question WHERE questionID NOT IN (SELECT questionID FROM Answer)")
       w=cursor.execute("SELECT Question.questionID, Question.question  FROM Question where questionID=1 or  questionID=2 or  questionID=3 or  questionID=4 or questionID=5")
       
       #w=cursor.execute("SELECT  Question.questionID, Question.question, Answer.StudentAnswer FROM Question INNER JOIN Answer ON Question.questionID=Answer.questionID;")
       #we=cursor.execute("INSERT INTO Answer (questionID) SELECT questionID FROM Question;")
      # we=cursor.execute("SELECT Question.question FROM Question")
      # we=cursor.execute("select question from Question")

         
       res=w.fetchall()
      
        
       return render(request,'studenAn.html',{'Quest':res})

 
#let the student input thier answers 
def addnew2(request):
     condata=pyodbc.connect('Driver={sql server};'
       'Server=LAPTOP-M7N01MTM;'
       'Database=test;' 
       'Trusted_Connection=yes;') 
     
     
     if request.method=="POST":
       if request.POST.get('StudentAnswer'):
         ins=StudeA()
        # q= Quest()
          
         ins.StudentAnswer= request.POST.get('StudentAnswer') 
         ins.StudentAnswer2= request.POST.get('StudentAnswer2')
         ins.StudentAnswer3= request.POST.get('StudentAnswer3') 
         ins.StudentAnswer4= request.POST.get('StudentAnswer4') 
         ins.StudentAnswer5= request.POST.get('StudentAnswer5') 
          
         
          
         
          
        
         cursor=condata.cursor()
         #cursor.execute("insert into sttable('"+ins.question+"','"+ ins.answer+"')")
         #cursor.execute("insert into Answer values ('"+ins.StudentAnswer+"')") 


         #cursor.execute("insert into Answer (StudentAnswer) values ('"+ins.StudentAnswer+"')") 
         #cursor.execute("SELECT Question.questionID, Question.question, Answer.StudentAnswer FROM Question INNER JOIN Answer ON Question.questionID=Answer.questionID;")

         #cursor.execute("INSERT INTO Answer (questionID) SELECT questionID FROM Question;")
         #cursor.execute("insert into Answer (StudentAnswer) values ('"+ins.StudentAnswer+"')")  

         #cursor.execute("INSERT INTO Answer (questionID) SELECT questionID FROM Question")
        # fk_AnswerQuestion

         #cursor.execute("insert into Answer(questionID) ( select 'Question.questionID', questionID from Question where Question.questionID not in ( select Answer.fk_AnswerQuestion from Answer)")
         #cursor.execute("SELECT Question.question FROM Question where questionID=1")
         #cursor.execute("insert into Answer (StudentAnswer) values ('"+ins.StudentAnswer+"') where questionID=1")
         
         first=cursor.execute("UPDATE Answer  SET StudentAnswer = ('"+ins.StudentAnswer+"') where questionID=1")   
         first.commit()

         second=cursor.execute("UPDATE Answer  SET StudentAnswer = ('"+ins.StudentAnswer2+"')where questionID=2") 
         second.commit() 

         third=cursor.execute("UPDATE Answer  SET StudentAnswer = ('"+ins.StudentAnswer3+"')where questionID=3") 
         third.commit() 

         four=cursor.execute("UPDATE Answer  SET StudentAnswer = ('"+ins.StudentAnswer4+"')where questionID=4") 
         four.commit() 

         five=cursor.execute("UPDATE Answer  SET StudentAnswer = ('"+ins.StudentAnswer5+"')where questionID=5") 
         five.commit() 
         
         return HttpResponseRedirect(reverse('connectstudent')) 
           
#connect the question table and display it to the teacher after they input questions 

def connectsql(request):
    
       condata=pyodbc.connect('Driver={sql server};'
       'Server=LAPTOP-M7N01MTM;'
       'Database=test;' 
       'Trusted_Connection=yes;')
       cursor=condata.cursor()
       we=cursor.execute("select * from Question")
      


         
       res=cursor.fetchall()
       print("the number is: ")
       print(we, we.rowcount, len(res))
       return render(request,'index.html',{'Quest':res})
#display the add form for the teacher
def addQA(request):
  template = loader.get_template('addQA.html')
  return HttpResponse(template.render({}, request))

  #let the teacher input question until 20 questions and return them after input the questuons to the (connectsql)which display the questions that have been added 
def addnew(request):
     condata=pyodbc.connect('Driver={sql server};'
       'Server=LAPTOP-M7N01MTM;'
       'Database=test;' 
       'Trusted_Connection=yes;') 
  
 
     if request.method=="POST":
       if request.POST.get('questionID') and request.POST.get('question')and request.POST.get('answer')and request.POST.get('mark'):
         ins=Quest()
         ins.questionID=request.POST.get('questionID')
         ins.question=request.POST.get('question') 
         ins.answer= request.POST.get('answer') 
         ins.mark=request.POST.get('mark')
        
         cursor=condata.cursor()
         #cursor.execute("insert into sttable('"+ins.question+"','"+ ins.answer+"')")
         cursor.execute("insert into Question values ('"+ins.questionID+"','"+ ins.question+"','"+ ins.answer+"','"+ ins.mark+"')")

         
         we=cursor.execute("select * from Question")
      

         #count the lenth of the rwo in the table and add message if the staff exceed the number of inserted Q and A
         
         res=we.fetchall()
         print("the new number is: ")
         
         print(len(res))
         if (len(res) >= 20):
             
            messages.error(request, 'sorry you cannot exceed this number of Question!')
            return HttpResponseRedirect(reverse('connectsql')) 
             
         else:
            
           cursor.commit()
          
          
           return HttpResponseRedirect(reverse('connectsql')) 
            
      
             
  
          

 
       
         
     