from django.db import models


class Quest(models.Model):
  questionID = models.IntegerField(null=True) 
  question = models.CharField(max_length=255)
  answer = models.CharField(max_length=255)
  mark = models.IntegerField(null=True) 


class StudeA(models.Model):
  questionID = models.IntegerField(null=True) 
  StudentID=  models.IntegerField(null=True) 
  StudentAnswer = models.CharField(max_length=255,null=True)
   


 
 