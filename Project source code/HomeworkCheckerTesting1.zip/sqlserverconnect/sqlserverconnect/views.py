from django.shortcuts import render
from sqlserverconnect.models import sqlserverconn
import pyodbc

def loggg(request):
    conn=pyodbc.connect('Driver={sql server};'
                        'Server=DESKTOP-46ON81A;'
                        'Database=HomeworkChecker;'
                        'Trusted_Connection=yes;' )
    cursor=conn.cursor()
    cursor.execute("select * from Students")
    result=cursor.fetchall()
    return render(request,'student login.html',{'sqlserverconn':result})


def connsql(request):
    conn=pyodbc.connect('Driver={sql server};'
                        'Server=DESKTOP-46ON81A;'
                        'Database=HomeworkChecker;'
                        'Trusted_Connection=yes;' )
    cursor=conn.cursor()
    cursor.execute("select * from Students")
    result=cursor.fetchall()
    return render(request,'index.html',{'sqlserverconn':result})


def question(request):
    conn=pyodbc.connect('Driver={sql server};'
                        'Server=DESKTOP-46ON81A;'
                        'Database=HomeworkChecker;'
                        'Trusted_Connection=yes;' )
    cursor=conn.cursor()
    cursor.execute("select * from Question")
    result=cursor.fetchall()
    return render(request,'all question.html',{'question':result})

