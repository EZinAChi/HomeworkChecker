 
from django.contrib import admin
from django.urls import path
from . import views 
urlpatterns = [

     path('admin/', admin.site.urls),
     
     path('',views.connectstudent, name ='connectstudent'),
     path('addnew2/', views.addnew2, name='addnew2'),
     #path('',views.connectsql, name ='connectsql'),
    
     #path('add/', views.addQA, name='addQA'),
    # path('add/addnew/', views.addnew, name='addnew'),
]
