from django.shortcuts import render
from prac.models import Quest,StudeA
 
 
import pyodbc
from django.http import HttpResponse,HttpResponseRedirect 
from django.template import loader
 
from django.urls import reverse
from django.core.exceptions import ValidationError
from django import forms
from django.contrib import messages

def connectstudent(request):
    
       condata=pyodbc.connect('Driver={sql server};'
       'Server=LAPTOP-M7N01MTM;'
       'Database=test;' 
       'Trusted_Connection=yes;')
       cursor=condata.cursor()
       we=cursor.execute("SELECT Question.questionID, Question.question, Answer.StudentAnswer FROM Question INNER JOIN Answer ON Question.questionID=Answer.questionID;")
      # we=cursor.execute("SELECT Question.question FROM Question")

       #we=cursor.execute("INSERT INTO Answer (questionID) SELECT questionID FROM Question;")
      # we=cursor.execute("SELECT Question.question FROM Question")
      # we=cursor.execute("select question from Question")

         
       res=cursor.fetchall()
        
       return render(request,'studenAn.html',{'Quest':res})

 

def addnew2(request):
     condata=pyodbc.connect('Driver={sql server};'
       'Server=LAPTOP-M7N01MTM;'
       'Database=test;' 
       'Trusted_Connection=yes;') 
  
 
     if request.method=="POST":
       if request.POST.get('StudentAnswer'):
         ins=StudeA()
          
         ins.StudentAnswer= request.POST.get('StudentAnswer') 
          
        
         cursor=condata.cursor()
         #cursor.execute("insert into sttable('"+ins.question+"','"+ ins.answer+"')")
         #cursor.execute("insert into Answer values ('"+ins.StudentAnswer+"')") 


         #cursor.execute("insert into Answer (StudentAnswer) values ('"+ins.StudentAnswer+"')") 
         #cursor.execute("SELECT Question.questionID, Question.question, Answer.StudentAnswer FROM Question INNER JOIN Answer ON Question.questionID=Answer.questionID;")

      
         cursor.execute("insert into Answer (StudentAnswer) values ('"+ins.StudentAnswer+"')")  
         
            
         cursor.commit()
          
          
         return HttpResponseRedirect(reverse('connectstudent')) 
            


def connectsql(request):
    
       condata=pyodbc.connect('Driver={sql server};'
       'Server=LAPTOP-M7N01MTM;'
       'Database=test;' 
       'Trusted_Connection=yes;')
       cursor=condata.cursor()
       we=cursor.execute("select * from Question")
      


         
       res=cursor.fetchall()
       print("the number is: ")
       print(we, we.rowcount, len(res))
       return render(request,'index.html',{'Quest':res})

def addQA(request):
  template = loader.get_template('addQA.html')
  return HttpResponse(template.render({}, request))

def addnew(request):
     condata=pyodbc.connect('Driver={sql server};'
       'Server=LAPTOP-M7N01MTM;'
       'Database=test;' 
       'Trusted_Connection=yes;') 
  
 
     if request.method=="POST":
       if request.POST.get('questionID') and request.POST.get('question')and request.POST.get('answer')and request.POST.get('mark'):
         ins=Quest()
         ins.questionID=request.POST.get('questionID')
         ins.question=request.POST.get('question') 
         ins.answer= request.POST.get('answer') 
         ins.mark=request.POST.get('mark')
        
         cursor=condata.cursor()
         #cursor.execute("insert into sttable('"+ins.question+"','"+ ins.answer+"')")
         cursor.execute("insert into Question values ('"+ins.questionID+"','"+ ins.question+"','"+ ins.answer+"','"+ ins.mark+"')")

         
         we=cursor.execute("select * from Question")
      

         #count the lenth of the rwo in the table and add message if the staff exceed the number of inserted Q and A
         
         res=we.fetchall()
         print("the new number is: ")
         
         print(len(res))
         if (len(res) >= 20):
             
            messages.error(request, 'sorry you cannot exceed this number of Question!')
            return HttpResponseRedirect(reverse('connectsql')) 
             
         else:
            
           cursor.commit()
          
          
           return HttpResponseRedirect(reverse('connectsql')) 
            
      
             
  
          

 
       
         
     